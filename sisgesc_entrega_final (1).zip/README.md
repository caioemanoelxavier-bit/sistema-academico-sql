# SisGESC - Sistema de Gestao Escolar em SQL

Projeto academico desenvolvido para a entrega final de Banco de Dados, com foco em modelagem relacional, integridade referencial, operacoes OLTP, modelagem OLAP, ETL, performance e governanca.

## Modulos

- Academico
- Financeiro
- Recursos Humanos
- BI / OLAP

## Tecnologias

- MySQL 8+
- SQL DDL e DML
- Modelo Relacional
- Star Schema
- ETL
- Git e GitHub

## Como executar

1. Abra o MySQL Workbench ou terminal MySQL.
2. Acesse a raiz do repositorio.
3. Execute:

```sql
SOURCE scripts/run_all.sql;
```

## Ordem dos scripts

1. `00_reset.sql` - limpa o ambiente
2. `01_ddl_oltp.sql` - cria as tabelas OLTP
3. `02_triggers_regras_negocio.sql` - implementa regras RN-01 a RN-05
4. `03_dml_carga_dados_idempotente.sql` - insere dados sem duplicar
5. `04_validacao_counts.sql` - valida total de registros
6. `05_consultas_oltp.sql` - consultas transacionais
7. `06_olap_star_schema.sql` - cria dimensoes e fato
8. `07_etl_oltp_para_olap.sql` - carrega o ambiente analitico
9. `08_validacao_oltp_olap.sql` - compara soma OLTP x OLAP
10. `09_indices_performance.sql` - cria indices e executa EXPLAIN

## Validacao de Idempotencia

O script de carga pode ser executado duas vezes. A quantidade de registros deve permanecer igual, provando que nao houve duplicidade.

## Validacao OLTP x OLAP

A soma de `tb_pagamento.vlr_pago` precisa ser igual a soma de `fato_pagamento.valor_pago`.

## Documentacao

A pasta `docs/` deve conter:

- Dicionario de dados atualizado
- DER OLTP/OLAP
- PDF de entrega final

## Autor

Caio Emanoel Xavier de Moraes
